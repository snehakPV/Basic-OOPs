﻿using System;
namespace Question1;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Input the string: ");
        string input=Console.ReadLine();
        Console.WriteLine("The string you entered is: "+input);
    }
}
